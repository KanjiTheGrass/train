(function () {
	const graphics_createCanvas = Graphics._createCanvas;
	Graphics._createCanvas = function() {
		graphics_createCanvas.apply(this, arguments);
		this._createKeyImage();
	};

	const buttons = ["ok", "escape","down","up","right","left"];
	const buttonID = [0,1];

	function generateButtonName(name) {
		return "img/keyImages/" + name + ".png";
	}

	function banDrag (buttonName, button) {
		this._onKeyUpButton(buttonName, button);
		return false;
	}

	Graphics._createKeyImage = function () {
		var num = 0
		const div = document.createElement("div");
		div.id = "keyInputImage";
		document.body.appendChild(div);
		device = Utils.isMobileDevice();
		var copyBan = function () {};
		buttons.forEach(function (name) {
			var button = document.createElement('img');
			button.src = generateButtonName(name);
			button.alt = name
			button.className = "keyButton "+name;
			button.ondragstart = banDrag.bind(Input, buttons[num], button);
			button.onmousedown = Input._onKeyDownButton.bind(Input, buttons[num], button);
			button.onmouseup = Input._onKeyUpButton.bind(Input, buttons[num], button);
			button.oncopy = copyBan;
			button.addEventListener("contextmenu", copyBan);

			button.addEventListener('touchstart', 
			Input._onKeyDownButton.bind(Input, buttons[num], button), false);
			button.addEventListener('touchend', 
			Input._onKeyUpButton.bind(Input, buttons[num], button));

			div.appendChild(button);
			num++;
		});
		Input._loadCssKeyButton(div);
		Graphics._updateKeySprites();
	}

	const _updateAllElements = Graphics._updateAllElements;
	Graphics._updateAllElements = function() {
		_updateAllElements.apply(this, arguments);
		Graphics._updateKeySprites()
	};

	Graphics._updateKeySprites = function () {
		var div = document.getElementById("keyInputImage");
		div.style.display = Utils.isMobileDevice() ? "unset" : "none";
	}

	Input._loadCssKeyButton = function (div) {
		var link = document.createElement("link");
		link.href = "img/keyImages/key.css";
		link.rel = "stylesheet";
		div.appendChild(link);
	}

	var canTouch = true;
	Input._onKeyDownButton = function(buttonName, button) {
		canTouch = false;
		TouchInput.clear();
		this.clear();
		this._currentState[buttonName] = true;
		button.src = generateButtonName("_click_" + buttonName);
	};
	
	Input._onKeyUpButton = function(buttonName, button) {
		canTouch = true;
		this.clear();
		this._currentState[buttonName] = false;
		button.src = generateButtonName(buttonName);
	};

	touchStart = TouchInput._onTouchStart;
	TouchInput._onTouchStart = function(event) {
		if (canTouch) touchStart.apply(this, arguments);
	};
		
	
	Input.keyImageButton = function (button) {
		if (button == buttons[0]) {
		}else if (button == buttons[1]){

		}
	}
})()